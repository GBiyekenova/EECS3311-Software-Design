package finassist.view;

import finassist.controller.FinancialController;
import finassist.model.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

/** Swing graphical View. */
public class GUIView extends JFrame implements FinancialView {
    private final FinancialController controller;
    private final JTextArea output = new JTextArea(10, 50);
    private final JLabel status = new JLabel(" ");

    // log entry fields
    private final JComboBox<String> kind = new JComboBox<>(new String[]{"Expense", "Income"});
    private final JTextField amount = new JTextField(10);
    private final JTextField date = new JTextField(LocalDate.now().toString(), 10);
    private final JTextField field1 = new JTextField(15); // category / source
    private final JTextField field2 = new JTextField(15); // merchant / type
    private final JTextField description = new JTextField(20);
    private final JLabel label1 = new JLabel("Category");
    private final JLabel label2 = new JLabel("Merchant");

    private final JTextField coachQuestion = new JTextField(30);
    private String lastInput = "";

    public GUIView(FinancialController controller) {
        super("FinAssist");
        this.controller = controller;
        controller.setView(this);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        output.setEditable(false);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Log entry", logPanel());
        tabs.add("Dashboard", dashboardPanel());
        tabs.add("Subscriptions", subscriptionPanel());
        tabs.add("AI coach", coachPanel());

        add(tabs, BorderLayout.NORTH);
        add(new JScrollPane(output), BorderLayout.CENTER);
        add(status, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
    }

    // ---- FinancialView ----
    @Override public void display(String data) {
        status.setForeground(Color.BLACK);
        status.setText(data.split("\n")[0]);
        output.append(data + "\n");
    }

    @Override public void displayError(String message) {
        status.setForeground(Color.RED);
        status.setText(message);
        output.append("ERROR: " + message + "\n");
    }

    @Override public void showDashboard(MonthlySummary s) {
        display(String.format("Income: $%.2f | Expenses: $%.2f | Profit: $%.2f | Savings rate: %.1f%%",
                s.getTotalIncome(), s.getTotalExpenses(), s.getProfit(), s.calculateSavingsRate() * 100));
    }

    @Override public String getUserInput() { return lastInput; }

    /** Builds the entry from the form and sends it to the controller (class diagram: submitEntry). */
    public void submitEntry(FinancialEntry entry) {
        if (entry instanceof Income) controller.logIncome((Income) entry);
        else controller.logExpense((Expense) entry);
    }

    // ---- panels ----
    private JPanel logPanel() {
        JPanel p = new JPanel(new GridLayout(0, 2, 6, 6));
        p.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        kind.addActionListener(e -> {
            boolean exp = kind.getSelectedItem().equals("Expense");
            label1.setText(exp ? "Category" : "Source");
            label2.setText(exp ? "Merchant" : "Type");
        });
        p.add(new JLabel("Kind")); p.add(kind);
        p.add(new JLabel("Amount")); p.add(amount);
        p.add(new JLabel("Date (YYYY-MM-DD)")); p.add(date);
        p.add(label1); p.add(field1);
        p.add(label2); p.add(field2);
        p.add(new JLabel("Description (optional)")); p.add(description);
        JButton save = new JButton("Save");
        save.addActionListener(e -> save());
        JButton voice = new JButton("Voice entry");
        voice.addActionListener(e -> controller.logVoiceEntry());
        p.add(save); p.add(voice);
        return p;
    }

    private void save() {
        double a;
        LocalDate d;
        try {
            a = Double.parseDouble(amount.getText().trim());
            if (a <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) { displayError("Amount must be a positive number."); return; }
        try { d = LocalDate.parse(date.getText().trim()); }
        catch (RuntimeException ex) { displayError("Date must look like 2026-11-06."); return; }
        FinancialEntry entry = kind.getSelectedItem().equals("Expense")
                ? new Expense(a, d, description.getText(), field1.getText(), field2.getText())
                : new Income(a, d, description.getText(), field1.getText(), field2.getText());
        submitEntry(entry);
    }

    private JPanel dashboardPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JSpinner month = new JSpinner(new SpinnerNumberModel(LocalDate.now().getMonthValue(), 1, 12, 1));
        JSpinner year = new JSpinner(new SpinnerNumberModel(LocalDate.now().getYear(), 2000, 2100, 1));
        year.setEditor(new JSpinner.NumberEditor(year, "#"));
        JButton show = new JButton("Show dashboard");
        show.addActionListener(e -> controller.requestDashboard((int) month.getValue(), (int) year.getValue()));
        JButton goals = new JButton("Goal summary");
        goals.addActionListener(e -> controller.requestGoalSummary());
        JButton savings = new JButton("Savings advice");
        savings.addActionListener(e -> controller.requestSavingsAdvice());
        p.add(new JLabel("Month")); p.add(month); p.add(new JLabel("Year")); p.add(year);
        p.add(show); p.add(goals); p.add(savings);
        return p;
    }

    private JPanel subscriptionPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField name = new JTextField(10), amt = new JTextField(6), billing = new JTextField(LocalDate.now().toString(), 9);
        JComboBox<String> freq = new JComboBox<>(new String[]{"MONTHLY", "YEARLY"});
        JButton add = new JButton("Add subscription");
        add.addActionListener(e -> {
            try {
                double a = Double.parseDouble(amt.getText().trim());
                if (a <= 0 || name.getText().isBlank()) throw new IllegalArgumentException();
                controller.manageSubscription(new Subscription(name.getText().trim(), a,
                        (String) freq.getSelectedItem(), LocalDate.parse(billing.getText().trim())));
            } catch (RuntimeException ex) {
                displayError("Enter a name, a positive amount and a date like 2026-11-06.");
            }
        });
        p.add(new JLabel("Name")); p.add(name); p.add(new JLabel("Amount")); p.add(amt);
        p.add(freq); p.add(new JLabel("Billing date")); p.add(billing); p.add(add);
        return p;
    }

    private JPanel coachPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton ask = new JButton("Ask");
        wireAskButton(ask);
        p.add(new JLabel("Question")); p.add(coachQuestion); p.add(ask);
        return p;
    }

    private void wireAskButton(JButton ask) {
        ask.addActionListener(e -> {
            lastInput = coachQuestion.getText().trim();
            if (lastInput.isEmpty()) { displayError("Type a question first."); return; }
            controller.askFinancialCoach(getUserInput());
            coachQuestion.setText("");
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUIView(new FinancialController()).setVisible(true));
    }
}
