package finassist.view;

import finassist.controller.FinancialController;
import finassist.model.*;

import java.time.LocalDate;
import java.util.Scanner;

/** Command-line View. */
public class CLIView implements FinancialView {
    private final FinancialController controller;
    private final Scanner in = new Scanner(System.in);

    public CLIView(FinancialController controller) {
        this.controller = controller;
        controller.setView(this);
    }

    @Override public void display(String data) { System.out.println(data); }
    @Override public void displayError(String message) { System.out.println("ERROR: " + message); }

    @Override
    public void showDashboard(MonthlySummary s) {
        System.out.printf("Income: $%.2f%nExpenses: $%.2f%nProfit: $%.2f%nSavings rate: %.1f%%%n",
                s.getTotalIncome(), s.getTotalExpenses(), s.getProfit(), s.calculateSavingsRate() * 100);
    }

    @Override
    public String getUserInput() { return in.hasNextLine() ? in.nextLine().trim() : ""; }

    private String ask(String prompt) { System.out.print(prompt); return getUserInput(); }

    public void run() {
        while (true) {
            System.out.println("\n=== FinAssist ===");
            System.out.println("1 Log expense   2 Log income   3 Voice entry   4 Dashboard");
            System.out.println("5 Goal summary  6 Savings advice  7 Add subscription  8 Ask coach  0 Exit");
            String choice = ask("> ");
            try {
                switch (choice) {
                    case "1": logExpense(); break;
                    case "2": logIncome(); break;
                    case "3": controller.logVoiceEntry(); break;
                    case "4": dashboard(); break;
                    case "5": controller.requestGoalSummary(); break;
                    case "6": controller.requestSavingsAdvice(); break;
                    case "7": addSubscription(); break;
                    case "8": controller.askFinancialCoach(ask("Question: ")); break;
                    case "0": return;
                    default: displayError("Unknown option.");
                }
            } catch (RuntimeException e) {
                displayError("Invalid input (" + e.getMessage() + "). Amounts are numbers, dates are YYYY-MM-DD.");
            }
        }
    }

    private double amount() {
        double a = Double.parseDouble(ask("Amount: "));
        if (a <= 0) throw new IllegalArgumentException("amount must be positive");
        return a;
    }

    private void logExpense() {
        double a = amount();
        LocalDate d = LocalDate.parse(ask("Date (YYYY-MM-DD): "));
        controller.logExpense(new Expense(a, d, ask("Description (optional): "), ask("Category: "), ask("Merchant: ")));
    }

    private void logIncome() {
        double a = amount();
        LocalDate d = LocalDate.parse(ask("Date (YYYY-MM-DD): "));
        controller.logIncome(new Income(a, d, ask("Description (optional): "), ask("Source: "), ask("Type: ")));
    }

    private void dashboard() {
        controller.requestDashboard(Integer.parseInt(ask("Month (1-12): ")), Integer.parseInt(ask("Year: ")));
    }

    private void addSubscription() {
        String name = ask("Name: ");
        double a = amount();
        String freq = ask("Frequency (MONTHLY/YEARLY): ").toUpperCase();
        if (!freq.equals("MONTHLY") && !freq.equals("YEARLY")) throw new IllegalArgumentException("frequency");
        controller.manageSubscription(new Subscription(name, a, freq, LocalDate.parse(ask("Billing date (YYYY-MM-DD): "))));
    }
}
