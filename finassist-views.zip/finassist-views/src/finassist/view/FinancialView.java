package finassist.view;

/** The View interface of the MVC pattern. GUIView and CLIView implement it. */
public interface FinancialView {
    void display(String data);
    void displayError(String message);
    void showDashboard(finassist.model.MonthlySummary summary);
    String getUserInput();
}
