package finassist;

import finassist.controller.FinancialController;
import finassist.view.CLIView;
import finassist.view.GUIView;

import javax.swing.SwingUtilities;

/** Usage: java finassist.Main gui | cli  (default: gui) */
public class Main {
    public static void main(String[] args) {
        FinancialController controller = new FinancialController();
        if (args.length > 0 && args[0].equalsIgnoreCase("cli")) {
            new CLIView(controller).run();
        } else {
            SwingUtilities.invokeLater(() -> new GUIView(controller).setVisible(true));
        }
    }
}
