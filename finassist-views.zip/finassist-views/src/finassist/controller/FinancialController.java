package finassist.controller;

import finassist.model.*;
import finassist.view.FinancialView;

import java.util.ArrayList;
import java.util.List;

/**
 * Controller of the MVC pattern.
 * TEMPORARY: it keeps data in memory so the views can run. Later, replace the
 * body of each method with a call to FinAssistFacade (same method names as the class diagram).
 */
public class FinancialController {
    private FinancialView view;
    private final List<FinancialEntry> entries = new ArrayList<>();
    private final List<Subscription> subscriptions = new ArrayList<>();

    public void setView(FinancialView view) { this.view = view; }

    public void logIncome(Income income) {
        entries.add(income);
        view.display(String.format("Income saved: $%.2f", income.getAmount()));
    }

    public void logExpense(Expense expense) {
        entries.add(expense);
        view.display(String.format("Expense saved: $%.2f", expense.getAmount()));
    }

    public void logVoiceEntry() {
        view.displayError("Voice entry is not available yet (needs VoiceInputService).");
    }

    public void requestDashboard(int month, int year) {
        double inc = 0, exp = 0;
        int count = 0;
        for (FinancialEntry e : entries) {
            if (e.getDate().getMonthValue() != month || e.getDate().getYear() != year) continue;
            count++;
            if (e instanceof Income) inc += e.getAmount(); else exp += e.getAmount();
        }
        if (count == 0) { view.display("No financial data for this month."); return; }
        view.showDashboard(new MonthlySummary(inc, exp));
    }

    public void requestGoalSummary() { view.display("Goal summary is not available yet."); }
    public void requestSavingsAdvice() { view.display("Savings advice is not available yet (needs SavingsAnalyzer)."); }
    public void askFinancialCoach(String question) { view.display("Coach is not available yet (needs FinancialCoachAgent). Your question: " + question); }

    public void manageSubscription(Subscription s) {
        subscriptions.add(s);
        view.display(String.format("Subscription %s saved: $%.2f/month, $%.2f/year", s.getName(), s.getMonthlyCost(), s.getAnnualCost()));
    }
}
