package finassist.model;

import java.time.LocalDate;

public abstract class FinancialEntry {
    private final double amount;
    private final LocalDate date;
    private final String description;

    protected FinancialEntry(double amount, LocalDate date, String description) {
        this.amount = amount;
        this.date = date;
        this.description = description;
    }

    public double getAmount() { return amount; }
    public LocalDate getDate() { return date; }
    public String getDescription() { return description; }
}
