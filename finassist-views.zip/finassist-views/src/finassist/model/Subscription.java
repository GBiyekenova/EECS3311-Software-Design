package finassist.model;

import java.time.LocalDate;

public class Subscription {
    private final String name;
    private final double amount;
    private final String frequency; // "MONTHLY" or "YEARLY"
    private final LocalDate billingDate;

    public Subscription(String name, double amount, String frequency, LocalDate billingDate) {
        this.name = name;
        this.amount = amount;
        this.frequency = frequency;
        this.billingDate = billingDate;
    }

    public String getName() { return name; }
    public double getAmount() { return amount; }
    public String getFrequency() { return frequency; }
    public LocalDate getBillingDate() { return billingDate; }
    public double getMonthlyCost() { return "YEARLY".equalsIgnoreCase(frequency) ? amount / 12 : amount; }
    public double getAnnualCost() { return getMonthlyCost() * 12; }
}
