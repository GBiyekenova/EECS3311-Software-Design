package finassist.model;

public class MonthlySummary {
    private final double totalIncome;
    private final double totalExpenses;

    public MonthlySummary(double totalIncome, double totalExpenses) {
        this.totalIncome = totalIncome;
        this.totalExpenses = totalExpenses;
    }

    public double getTotalIncome() { return totalIncome; }
    public double getTotalExpenses() { return totalExpenses; }
    public double getProfit() { return totalIncome - totalExpenses; }
    public double calculateProfit() { return getProfit(); }
    public double calculateSavingsRate() { return totalIncome == 0 ? 0 : getProfit() / totalIncome; }
}
