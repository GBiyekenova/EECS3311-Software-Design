Compile:  mkdir out && javac -d out $(find src -name '*.java')
Run GUI:  java -cp out finassist.Main gui
Run CLI:  java -cp out finassist.Main cli
